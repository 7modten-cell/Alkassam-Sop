export type Language = 'ar' | 'en';

export type CategoryId = 'all' | 'tops-tees' | 'hoodies-sweats' | 'new-arrivals' | 'essentials';

export type PaymentMethod = 'Vodafone Cash' | 'InstaPay';

export interface Product {
  id: string;
  handle: string;
  title: {
    ar: string;
    en: string;
  };
  description: {
    ar: string;
    en: string;
  };
  category: Exclude<CategoryId, 'all'>;
  collections: CategoryId[];
  price: number; // in EGP
  image: string; // Primary front image
  images: {
    url: string;
    alt: string;
    color?: string;
  }[];
  isNew?: boolean;
  inStock: boolean;
  sizes: string[];
  colors: {
    id: string;
    ar: string;
    en: string;
    hex: string;
  }[];
}

export interface CartItem {
  cartItemId: string;
  product: Product;
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
}

export interface Governorate {
  id: string;
  ar: string;
  en: string;
}

export interface SubmittedOrder {
  orderId: string;
  createdAt: string;
  customer: {
    fullName: string;
    phone: string;
    governorateName: string;
    address: string;
    paymentMethod: PaymentMethod;
  };
  items: CartItem[];
  totalAmount: number;
  receiptPreviewUrl: string;
  telegramCaption: string;
  telegramDelivered: boolean;
  telegramNote?: string;
}
