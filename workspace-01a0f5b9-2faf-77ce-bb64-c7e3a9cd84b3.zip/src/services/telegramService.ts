import { CartItem, Language, PaymentMethod } from '../types/shop';

export const TELEGRAM_BOT_TOKEN = '8776861105:AAGqXFoHNMGP6MsSzI4USyqKHUyOdQHQfxo';
export const TELEGRAM_BOT_USERNAME = 'menu_try60bot';
export const TELEGRAM_API_BASE = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}`;

export interface FormatCaptionParams {
  fullName: string;
  phone: string;
  governorateName: string;
  address: string;
  paymentMethod: PaymentMethod;
  totalAmount: number;
  items: CartItem[];
  lang: Language;
}

/**
 * Formats the order details into the exact required Telegram caption string:
 * "🆕 New Order!
 * 👤 Name: [Name]
 * 📞 Phone: [Phone]
 * 📍 Address: [Governorate] - [Address]
 * 💳 Payment: [InstaPay/Vodafone Cash]
 * 💰 Total: [Total Amount] EGP
 * 🛒 Items:
 * * 2x Product A
 * * 1x Product B"
 */
export function formatTelegramOrderCaption({
  fullName,
  phone,
  governorateName,
  address,
  paymentMethod,
  totalAmount,
  items,
  lang,
}: FormatCaptionParams): string {
  const itemsLines = items
    .map((item) => {
      const variantSuffix =
        item.selectedSize || item.selectedColor
          ? ` (${[item.selectedColor, item.selectedSize].filter(Boolean).join(' / ')})`
          : '';
      return `* ${item.quantity}x ${item.product.title[lang]}${variantSuffix}`;
    })
    .join('\n');

  return [
    '🆕 New Order!',
    `👤 Name: ${fullName.trim()}`,
    `📞 Phone: ${phone.trim()}`,
    `📍 Address: ${governorateName} - ${address.trim()}`,
    `💳 Payment: ${paymentMethod}`,
    `💰 Total: ${totalAmount} EGP`,
    '🛒 Items:',
    itemsLines,
  ].join('\n');
}

export async function detectLatestTelegramChatId(): Promise<{
  chatId: string | null;
  chatTitle?: string;
}> {
  try {
    const response = await fetch(`${TELEGRAM_API_BASE}/getUpdates?limit=20`, {
      method: 'GET',
    });
    const data = await response.json();
    if (data?.ok && Array.isArray(data.result) && data.result.length > 0) {
      for (let i = data.result.length - 1; i >= 0; i--) {
        const update = data.result[i];
        const chat =
          update?.message?.chat ||
          update?.edited_message?.chat ||
          update?.channel_post?.chat ||
          update?.my_chat_member?.chat;
        if (chat?.id) {
          const detectedId = String(chat.id);
          const title =
            chat.title ||
            [chat.first_name, chat.last_name].filter(Boolean).join(' ') ||
            chat.username ||
            detectedId;
          localStorage.setItem('quiet_shop_telegram_chat_id', detectedId);
          return { chatId: detectedId, chatTitle: title };
        }
      }
    }
    return { chatId: null };
  } catch {
    return { chatId: null };
  }
}

export interface SendTelegramOrderParams extends FormatCaptionParams {
  receiptFile: File;
  chatId?: string;
}

export interface SendTelegramOrderResult {
  success: boolean;
  deliveredLive: boolean;
  caption: string;
  usedChatId?: string;
  errorMessage?: string;
}

export async function sendOrderToTelegram(
  params: SendTelegramOrderParams
): Promise<SendTelegramOrderResult> {
  const caption = formatTelegramOrderCaption(params);

  let targetChatId = (
    params.chatId ||
    localStorage.getItem('quiet_shop_telegram_chat_id') ||
    ''
  ).trim();

  if (!targetChatId) {
    const detected = await detectLatestTelegramChatId();
    if (detected.chatId) {
      targetChatId = detected.chatId;
    }
  }

  const formData = new FormData();
  if (targetChatId) {
    formData.append('chat_id', targetChatId);
  }
  formData.append('photo', params.receiptFile);
  formData.append('caption', caption);

  try {
    const response = await fetch(`${TELEGRAM_API_BASE}/sendPhoto`, {
      method: 'POST',
      body: formData,
    });

    const result = await response.json();

    if (response.ok && result?.ok) {
      if (targetChatId) {
        localStorage.setItem('quiet_shop_telegram_chat_id', targetChatId);
      }
      return {
        success: true,
        deliveredLive: true,
        caption,
        usedChatId: targetChatId,
      };
    }

    return {
      success: true,
      deliveredLive: false,
      caption,
      usedChatId: targetChatId || undefined,
      errorMessage:
        result?.description || 'Chat ID not initialized with @menu_try60bot yet',
    };
  } catch (err) {
    return {
      success: true,
      deliveredLive: false,
      caption,
      usedChatId: targetChatId || undefined,
      errorMessage: err instanceof Error ? err.message : 'Network error',
    };
  }
}
