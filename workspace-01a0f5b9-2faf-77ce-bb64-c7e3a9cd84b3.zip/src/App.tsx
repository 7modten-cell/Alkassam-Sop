import React, { useState, useEffect, useMemo } from 'react';
import { SlidersHorizontal } from 'lucide-react';
import {
  CartItem,
  CategoryId,
  Language,
  Product,
  SubmittedOrder,
} from './types/shop';
import { translations } from './data/i18n';
import { PRODUCTS } from './data/products';
import { Header } from './components/Header';
import { HamburgerMenu } from './components/HamburgerMenu';
import { ProductCard } from './components/ProductCard';
import { ProductQuickView } from './components/ProductQuickView';
import { FilterPanel, SortOption } from './components/FilterPanel';
import { SearchOverlay } from './components/SearchOverlay';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderSuccessModal } from './components/OrderSuccessModal';
import { detectLatestTelegramChatId } from './services/telegramService';

export function App() {
  // Default state: Arabic language ('ar') with strict RTL layout
  const [lang, setLang] = useState<Language>('ar');
  const [darkMode, setDarkMode] = useState<boolean>(false);

  // Filter & Sort states (matching VOID™ /products page)
  const [selectedCategory, setSelectedCategory] = useState<CategoryId>('all');
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<SortOption>('default');

  // Active Product for the VOID™ 3-column Product Detail view (null = /products catalog view)
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);

  // Drawers & Modals
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [submittedOrder, setSubmittedOrder] = useState<SubmittedOrder | null>(
    null
  );

  // Cart state
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('void_egypt_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Telegram Chat ID
  const [savedChatId, setSavedChatId] = useState<string>(() => {
    return localStorage.getItem('quiet_shop_telegram_chat_id') || '';
  });

  // Sync HTML dir (rtl / ltr) and lang attribute dynamically
  useEffect(() => {
    const dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.setAttribute('dir', dir);
    document.documentElement.setAttribute('lang', lang);
  }, [lang]);

  // Sync Dark Mode class
  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
  }, [darkMode]);

  // Persist cart
  useEffect(() => {
    try {
      localStorage.setItem('void_egypt_cart', JSON.stringify(cart));
    } catch {
      // ignore storage errors
    }
  }, [cart]);

  // Auto-detect Telegram Chat ID silently if not set
  useEffect(() => {
    if (!savedChatId) {
      detectLatestTelegramChatId().then((res) => {
        if (res.chatId) {
          setSavedChatId(res.chatId);
        }
      });
    }
  }, [savedChatId]);

  const handleUpdateChatId = (id: string) => {
    setSavedChatId(id);
    localStorage.setItem('quiet_shop_telegram_chat_id', id);
  };

  const t = translations[lang];

  // Filtered products
  const filteredProducts = useMemo(() => {
    let list = [...PRODUCTS];

    if (selectedCategory !== 'all') {
      list = list.filter((p) => p.collections.includes(selectedCategory));
    }

    if (selectedSizes.length > 0) {
      list = list.filter((p) =>
        p.sizes.some((s) => selectedSizes.includes(s))
      );
    }

    if (inStockOnly) {
      list = list.filter((p) => p.inStock);
    }

    if (sortBy === 'price-low') {
      list.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-high') {
      list.sort((a, b) => b.price - a.price);
    }

    return list;
  }, [selectedCategory, selectedSizes, inStockOnly, sortBy]);

  // Cart operations
  const handleAddToCart = (
    product: Product,
    size: string = 'L',
    color: string = product.colors[0]?.[lang] || 'Black'
  ) => {
    const cartItemId = `${product.id}-${size}-${color}`;
    setCart((prev) => {
      const existing = prev.find((item) => item.cartItemId === cartItemId);
      if (existing) {
        return prev.map((item) =>
          item.cartItemId === cartItemId
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [
        ...prev,
        {
          cartItemId,
          product,
          quantity: 1,
          selectedSize: size,
          selectedColor: color,
        },
      ];
    });
    setIsCartOpen(true);
  };

  const handleQuickAdd = (product: Product) => {
    const defaultSize = product.sizes[1] || product.sizes[0] || 'M';
    const defaultColor = product.colors[0]?.[lang] || 'Black';
    const cartItemId = `${product.id}-${defaultSize}-${defaultColor}`;

    setCart((prev) => {
      const existing = prev.find((item) => item.cartItemId === cartItemId);
      if (existing) {
        return prev.map((item) =>
          item.cartItemId === cartItemId
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [
        ...prev,
        {
          cartItemId,
          product,
          quantity: 1,
          selectedSize: defaultSize,
          selectedColor: defaultColor,
        },
      ];
    });
  };

  const handleUpdateQuantity = (cartItemId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) =>
          item.cartItemId === cartItemId
            ? { ...item, quantity: item.quantity + delta }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const handleRemoveItem = (cartItemId: string) => {
    setCart((prev) => prev.filter((item) => item.cartItemId !== cartItemId));
  };

  const handleToggleSizeFilter = (size: string) => {
    setSelectedSizes((prev) =>
      prev.includes(size) ? prev.filter((s) => s !== size) : [...prev, size]
    );
  };

  const handleClearAllFilters = () => {
    setSelectedCategory('all');
    setSelectedSizes([]);
    setInStockOnly(false);
    setSortBy('default');
  };

  const totalCartItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div
      dir={lang === 'ar' ? 'rtl' : 'ltr'}
      className="min-h-screen bg-background text-foreground"
    >
      {/* Fixed Top Brutalist VOID™ Header */}
      <Header
        lang={lang}
        onToggleLang={() => setLang((prev) => (prev === 'ar' ? 'en' : 'ar'))}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode((prev) => !prev)}
        cartCount={totalCartItems}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenMenu={() => setIsMenuOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onLogoClick={() => {
          setActiveProduct(null);
          setSelectedCategory('all');
        }}
      />

      {/* Main Content */}
      <main className="pt-14">
        {activeProduct ? (
          <ProductQuickView
            product={activeProduct}
            onBack={() => setActiveProduct(null)}
            lang={lang}
            onAddToCart={handleAddToCart}
            onSelectProduct={(p) => setActiveProduct(p)}
          />
        ) : (
          /* Exact VOID™ /products Page Layout */
          <section className="page-padding py-16 min-h-screen">
            <div className="mb-12">
              <h1 className="text-lg uppercase">
                {selectedCategory === 'all'
                  ? t.allProductsTitle
                  : t.categories[selectedCategory]}
              </h1>
            </div>

            {/* Filter & Product Count Bar */}
            <div className="flex items-center justify-between mb-8 border-b border-border pb-4">
              <button
                type="button"
                onClick={() => setIsFilterOpen(true)}
                className="flex items-center gap-2 text-sm uppercase hover:opacity-60 transition-opacity"
              >
                <SlidersHorizontal className="w-4 h-4 stroke-[1.5]" />
                <span>{t.filtersButton}</span>
                {filteredProducts.length !== PRODUCTS.length && (
                  <span className="text-muted-foreground">
                    ({filteredProducts.length})
                  </span>
                )}
              </button>

              <span className="text-sm text-muted-foreground">
                {filteredProducts.length}{' '}
                {filteredProducts.length === 1
                  ? t.productSingular
                  : t.productsPlural}
              </span>
            </div>

            {/* Product Grid (grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6) */}
            {filteredProducts.length === 0 ? (
              <div className="py-20 text-center">
                <p className="text-sm text-muted-foreground mb-4">
                  {t.noProductsFound}
                </p>
                <button
                  type="button"
                  onClick={handleClearAllFilters}
                  className="text-xs uppercase underline underline-offset-4 hover:opacity-60"
                >
                  {t.clearFilters}
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
                {filteredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    lang={lang}
                    onSelectProduct={(p) => setActiveProduct(p)}
                    onQuickAdd={handleQuickAdd}
                  />
                ))}
              </div>
            )}
          </section>
        )}
      </main>

      {/* Hamburger Menu Drawer */}
      <HamburgerMenu
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        lang={lang}
        onToggleLang={() => setLang((prev) => (prev === 'ar' ? 'en' : 'ar'))}
        selectedCategory={selectedCategory}
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          setActiveProduct(null);
        }}
        onOpenSearch={() => setIsSearchOpen(true)}
        savedChatId={savedChatId}
        onChangeChatId={handleUpdateChatId}
      />

      {/* Slide-out Filter Panel */}
      <FilterPanel
        isOpen={isFilterOpen}
        onClose={() => setIsFilterOpen(false)}
        lang={lang}
        sortBy={sortBy}
        onSortChange={setSortBy}
        selectedSizes={selectedSizes}
        onToggleSize={handleToggleSizeFilter}
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
        inStockOnly={inStockOnly}
        onToggleInStock={setInStockOnly}
        onClearAll={handleClearAllFilters}
      />

      {/* Fullscreen Live Search Overlay */}
      <SearchOverlay
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        lang={lang}
        onSelectProduct={(p) => setActiveProduct(p)}
      />

      {/* Slide-out Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        lang={lang}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onProceedToCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
      />

      {/* Egyptian Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        lang={lang}
        items={cart}
        savedChatId={savedChatId}
        onChangeChatId={handleUpdateChatId}
        onOrderSuccess={(order) => {
          setCart([]);
          setIsCheckoutOpen(false);
          setSubmittedOrder(order);
        }}
      />

      {/* Order Success Modal */}
      <OrderSuccessModal
        order={submittedOrder}
        onClose={() => setSubmittedOrder(null)}
        lang={lang}
      />
    </div>
  );
}

export default App;
