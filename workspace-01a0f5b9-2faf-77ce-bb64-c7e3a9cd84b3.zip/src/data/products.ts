import { Product } from '../types/shop';

const ASSET_BASE = 'https://void-storefront-design.lovable.app/assets';

export const PRODUCTS: Product[] = [
  {
    id: 'demo-oversize-shirt',
    handle: 'oversize-shirt',
    title: {
      ar: 'تيشيرت أوفر سايز — أسود (Oversize Shirt)',
      en: 'Oversize Shirt',
    },
    description: {
      ar: 'تيشيرت قطن مصري ثقيل عالي الكثافة بقصة أوفر سايز مريحة وتصميم بسيط بدون تفاصيل زائدة.',
      en: 'Heavyweight cotton tee. Clean fit, no noise.',
    },
    category: 'tops-tees',
    collections: ['all', 'tops-tees', 'new-arrivals', 'essentials'],
    price: 950,
    image: `${ASSET_BASE}/tee-black-front-BAVXNyYn.png`,
    images: [
      {
        url: `${ASSET_BASE}/tee-black-front-BAVXNyYn.png`,
        alt: 'Oversize Shirt - black front',
        color: 'Black',
      },
      {
        url: `${ASSET_BASE}/tee-black-back-kWL0xWBW.png`,
        alt: 'Oversize Shirt - black back',
        color: 'Black',
      },
      {
        url: `${ASSET_BASE}/tee-white-front-C3JoucSg.png`,
        alt: 'Oversize Shirt - white front',
        color: 'White',
      },
      {
        url: `${ASSET_BASE}/tee-white-back-C58KaGlI.png`,
        alt: 'Oversize Shirt - white back',
        color: 'White',
      },
    ],
    isNew: true,
    inStock: true,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { id: 'Black', ar: 'أسود', en: 'Black', hex: '#000000' },
      { id: 'White', ar: 'أبيض', en: 'White', hex: '#ffffff' },
    ],
  },
  {
    id: 'demo-oversize-hoodie',
    handle: 'oversize-hoodie',
    title: {
      ar: 'هودي أوفر سايز ثقيل (Oversize Hoodie)',
      en: 'Oversize Hoodie',
    },
    description: {
      ar: 'هودي ثقيل مبطن بقصة أوفر سايز مريحة وهيكل متماسك للاستخدام اليومي.',
      en: 'Structured fleece hoodie. Oversized comfort.',
    },
    category: 'hoodies-sweats',
    collections: ['all', 'hoodies-sweats', 'essentials'],
    price: 1750,
    image: `${ASSET_BASE}/front-hoodie-CHRGReR9.png`,
    images: [
      {
        url: `${ASSET_BASE}/front-hoodie-CHRGReR9.png`,
        alt: 'Oversize Hoodie - front',
        color: 'Black',
      },
      {
        url: `${ASSET_BASE}/back-hoodie-DoiKBtXK.png`,
        alt: 'Oversize Hoodie - back',
        color: 'Black',
      },
    ],
    isNew: false,
    inStock: true,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [{ id: 'Black', ar: 'أسود', en: 'Black', hex: '#000000' }],
  },
  {
    id: 'demo-vintage-shirt',
    handle: 'vintage-shirt',
    title: {
      ar: 'تيشيرت فينتج مغسول (Vintage Shirt)',
      en: 'Vintage Shirt',
    },
    description: {
      ar: 'تيشيرت قطني معالج بالغسيل الكربوني لملمس ناعم وقصة فينتج مريحة.',
      en: 'Washed cotton tee with a lived-in feel. Relaxed vintage cut.',
    },
    category: 'tops-tees',
    collections: ['all', 'tops-tees', 'new-arrivals', 'essentials'],
    price: 1150,
    image: `${ASSET_BASE}/vintage-front-DYqQ-CCs.png`,
    images: [
      {
        url: `${ASSET_BASE}/vintage-front-DYqQ-CCs.png`,
        alt: 'Vintage Shirt - front',
        color: 'Washed Black',
      },
      {
        url: `${ASSET_BASE}/vintage-back-0vYtP9Jz.png`,
        alt: 'Vintage Shirt - back',
        color: 'Washed Black',
      },
    ],
    isNew: true,
    inStock: true,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { id: 'Washed Black', ar: 'أسود فينتج', en: 'Washed Black', hex: '#27272a' },
    ],
  },
  {
    id: 'demo-crewneck',
    handle: 'crewneck',
    title: {
      ar: 'سويت شيرت كرو نيك (Crewneck)',
      en: 'Crewneck',
    },
    description: {
      ar: 'سويت شيرت كلاسيكي بياقة دائرية من القطن الثقيل الناعم بقصة مريحة.',
      en: 'Classic crewneck sweatshirt. Soft fleece, relaxed fit.',
    },
    category: 'hoodies-sweats',
    collections: ['all', 'hoodies-sweats', 'new-arrivals', 'essentials'],
    price: 1550,
    image: `${ASSET_BASE}/crewneck-front-CjBuzJte.png`,
    images: [
      {
        url: `${ASSET_BASE}/crewneck-front-CjBuzJte.png`,
        alt: 'Crewneck - front',
        color: 'Washed Black',
      },
      {
        url: `${ASSET_BASE}/crewneck-back-BbhoF3V5.png`,
        alt: 'Crewneck - back',
        color: 'Washed Black',
      },
    ],
    isNew: true,
    inStock: true,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { id: 'Washed Black', ar: 'أسود فينتج', en: 'Washed Black', hex: '#27272a' },
    ],
  },
  {
    id: 'demo-oversize-shirt-white',
    handle: 'oversize-shirt-white',
    title: {
      ar: 'تيشيرت أوفر سايز — أبيض (Oversize Shirt White)',
      en: 'Oversize Shirt — White',
    },
    description: {
      ar: 'تيشيرت قطن مصري ثقيل باللون الأبيض النقي بقصة أوفر سايز مريحة.',
      en: 'Heavyweight optic white cotton tee. Clean architectural fit.',
    },
    category: 'tops-tees',
    collections: ['all', 'tops-tees', 'new-arrivals', 'essentials'],
    price: 950,
    image: `${ASSET_BASE}/tee-white-front-C3JoucSg.png`,
    images: [
      {
        url: `${ASSET_BASE}/tee-white-front-C3JoucSg.png`,
        alt: 'Oversize Shirt - white front',
        color: 'White',
      },
      {
        url: `${ASSET_BASE}/tee-white-back-C58KaGlI.png`,
        alt: 'Oversize Shirt - white back',
        color: 'White',
      },
      {
        url: `${ASSET_BASE}/tee-black-front-BAVXNyYn.png`,
        alt: 'Oversize Shirt - black front',
        color: 'Black',
      },
    ],
    isNew: true,
    inStock: true,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { id: 'White', ar: 'أبيض', en: 'White', hex: '#ffffff' },
      { id: 'Black', ar: 'أسود', en: 'Black', hex: '#000000' },
    ],
  },
  {
    id: 'demo-heavy-hoodie-edition',
    handle: 'archive-hoodie',
    title: {
      ar: 'هودي أرشيف ثقيل 500GSM (Archive Hoodie)',
      en: 'Archive Heavy Hoodie',
    },
    description: {
      ar: 'إصدار خاص من الهودي الثقيل بوزن 500 جرام مع ياقة مزدوجة وأكتاف منسدلة.',
      en: '500GSM heavyweight archive fleece hoodie with double-layered hood.',
    },
    category: 'hoodies-sweats',
    collections: ['all', 'hoodies-sweats', 'new-arrivals'],
    price: 1950,
    image: `${ASSET_BASE}/back-hoodie-DoiKBtXK.png`,
    images: [
      {
        url: `${ASSET_BASE}/back-hoodie-DoiKBtXK.png`,
        alt: 'Archive Hoodie - back view',
        color: 'Black',
      },
      {
        url: `${ASSET_BASE}/front-hoodie-CHRGReR9.png`,
        alt: 'Archive Hoodie - front view',
        color: 'Black',
      },
    ],
    isNew: true,
    inStock: true,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [{ id: 'Black', ar: 'أسود', en: 'Black', hex: '#000000' }],
  },
  {
    id: 'demo-boxy-vintage-tee',
    handle: 'boxy-vintage-tee',
    title: {
      ar: 'تيشيرت بوكسي فينتج (Boxy Vintage Tee)',
      en: 'Boxy Vintage Tee',
    },
    description: {
      ar: 'تيشيرت بقصة مربعة عريضة (Boxy Fit) من القطن المغسول عالي الجودة.',
      en: 'Wide boxy silhouette crafted from pigment-dyed heavyweight jersey.',
    },
    category: 'tops-tees',
    collections: ['all', 'tops-tees', 'essentials'],
    price: 1100,
    image: `${ASSET_BASE}/vintage-back-0vYtP9Jz.png`,
    images: [
      {
        url: `${ASSET_BASE}/vintage-back-0vYtP9Jz.png`,
        alt: 'Boxy Vintage Tee - back',
        color: 'Washed Black',
      },
      {
        url: `${ASSET_BASE}/vintage-front-DYqQ-CCs.png`,
        alt: 'Boxy Vintage Tee - front',
        color: 'Washed Black',
      },
    ],
    isNew: false,
    inStock: true,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { id: 'Washed Black', ar: 'أسود فينتج', en: 'Washed Black', hex: '#27272a' },
    ],
  },
  {
    id: 'demo-heavy-crewneck',
    handle: 'studio-crewneck',
    title: {
      ar: 'سويت شيرت ستوديو ثقيل (Studio Crewneck)',
      en: 'Studio Crewneck',
    },
    description: {
      ar: 'سويت شيرت بدون غطاء رأس بتقفيل مضلع سميك عند الأكمام والخصر.',
      en: 'Garment-dyed studio crewneck with heavy ribbed cuffs and hem.',
    },
    category: 'hoodies-sweats',
    collections: ['all', 'hoodies-sweats', 'essentials'],
    price: 1600,
    image: `${ASSET_BASE}/crewneck-back-BbhoF3V5.png`,
    images: [
      {
        url: `${ASSET_BASE}/crewneck-back-BbhoF3V5.png`,
        alt: 'Studio Crewneck - back',
        color: 'Washed Black',
      },
      {
        url: `${ASSET_BASE}/crewneck-front-CjBuzJte.png`,
        alt: 'Studio Crewneck - front',
        color: 'Washed Black',
      },
    ],
    isNew: false,
    inStock: true,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { id: 'Washed Black', ar: 'أسود فينتج', en: 'Washed Black', hex: '#27272a' },
    ],
  },
];
