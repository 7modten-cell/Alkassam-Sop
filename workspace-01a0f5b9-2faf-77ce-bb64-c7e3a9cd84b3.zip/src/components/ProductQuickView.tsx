import React, { useState, useEffect } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  X,
} from 'lucide-react';
import { Language, Product } from '../types/shop';
import { formatEGP, translations } from '../data/i18n';
import { PRODUCTS } from '../data/products';

interface ProductDetailViewProps {
  product: Product;
  onBack: () => void;
  lang: Language;
  onAddToCart: (product: Product, size: string, color: string) => void;
  onSelectProduct: (product: Product) => void;
}

export const ProductQuickView: React.FC<ProductDetailViewProps> = ({
  product,
  onBack,
  lang,
  onAddToCart,
  onSelectProduct,
}) => {
  const t = translations[lang];

  const [selectedColor, setSelectedColor] = useState<string>(
    product.colors[0]?.id || 'Black'
  );
  const [selectedSize, setSelectedSize] = useState<string>(
    product.sizes[1] || product.sizes[0] || 'M'
  );
  const [openAccordion, setOpenAccordion] = useState<string>('related');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  useEffect(() => {
    setSelectedColor(product.colors[0]?.id || 'Black');
    setSelectedSize(product.sizes[1] || product.sizes[0] || 'M');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [product]);

  // Filter images by selected color if color-specific images exist
  const colorImages = product.images.filter(
    (img) =>
      !img.color || img.color.toLowerCase() === selectedColor.toLowerCase()
  );
  const displayedImages =
    colorImages.length > 0 ? colorImages : product.images;

  const relatedProducts = PRODUCTS.filter((p) => p.id !== product.id).slice(
    0,
    2
  );

  const toggleAccordion = (id: string) => {
    setOpenAccordion((prev) => (prev === id ? '' : id));
  };

  const BackArrow = lang === 'ar' ? ChevronRight : ChevronLeft;

  const selectedColorObj =
    product.colors.find((c) => c.id === selectedColor) || product.colors[0];

  return (
    <div className="min-h-screen bg-background">
      {/* Top Back Button */}
      <div className="page-padding py-8 md:py-12">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-1 text-xs uppercase text-muted-foreground hover:text-foreground transition-colors"
        >
          <BackArrow className="w-4 h-4" />
          <span>{t.backToShop}</span>
        </button>
      </div>

      {/* VOID™ 3-Column Product Detail Layout */}
      <div className="page-padding pb-32 lg:pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_2fr_1fr] gap-8 lg:gap-12">
          {/* Column 1 (Sticky Left in LTR / Right in RTL): Product Info & Accordions */}
          <div className="order-2 lg:order-1 lg:h-[calc(100vh-6rem)] lg:sticky lg:top-20">
            <div className="h-full flex flex-col justify-center">
              <h1 className="text-sm uppercase mb-1">{product.title[lang]}</h1>
              <p className="text-sm text-muted-foreground mb-8">
                {formatEGP(product.price, lang)}
              </p>

              {/* Accordions */}
              <div className="w-full border-t border-border divide-y divide-border border-b">
                {/* Product Details */}
                <div>
                  <button
                    type="button"
                    onClick={() => toggleAccordion('details')}
                    className="w-full flex items-center justify-between py-4 text-xs uppercase text-start"
                  >
                    <span>{t.productDetailsAccordion}</span>
                    <ChevronDown
                      className={`w-4 h-4 transition-transform duration-200 ${
                        openAccordion === 'details' ? 'rotate-180' : ''
                      }`}
                    />
                  </button>
                  {openAccordion === 'details' && (
                    <div className="pb-4 text-xs text-muted-foreground leading-relaxed">
                      {product.description[lang]}
                    </div>
                  )}
                </div>

                {/* Sizing */}
                <div>
                  <button
                    type="button"
                    onClick={() => toggleAccordion('sizing')}
                    className="w-full flex items-center justify-between py-4 text-xs uppercase text-start"
                  >
                    <span>{t.sizingAccordion}</span>
                    <ChevronDown
                      className={`w-4 h-4 transition-transform duration-200 ${
                        openAccordion === 'sizing' ? 'rotate-180' : ''
                      }`}
                    />
                  </button>
                  {openAccordion === 'sizing' && (
                    <div className="pb-4 text-xs text-muted-foreground leading-relaxed">
                      {t.sizingText}
                    </div>
                  )}
                </div>

                {/* Shop the Look */}
                <div>
                  <button
                    type="button"
                    onClick={() => toggleAccordion('related')}
                    className="w-full flex items-center justify-between py-4 text-xs uppercase text-start"
                  >
                    <span>{t.shopTheLookAccordion}</span>
                    <ChevronDown
                      className={`w-4 h-4 transition-transform duration-200 ${
                        openAccordion === 'related' ? 'rotate-180' : ''
                      }`}
                    />
                  </button>
                  {openAccordion === 'related' && (
                    <div className="pb-4 grid grid-cols-2 gap-3">
                      {relatedProducts.map((rel) => (
                        <div
                          key={rel.id}
                          onClick={() => onSelectProduct(rel)}
                          className="group cursor-pointer"
                        >
                          <div className="aspect-square bg-secondary mb-2 overflow-hidden">
                            <img
                              src={rel.image}
                              alt={rel.title[lang]}
                              className="w-full h-full object-cover group-hover:opacity-80 transition-opacity"
                            />
                          </div>
                          <p className="text-xs uppercase truncate">
                            {rel.title[lang]}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {formatEGP(rel.price, lang)}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Delivery and Returns */}
                <div>
                  <button
                    type="button"
                    onClick={() => toggleAccordion('delivery')}
                    className="w-full flex items-center justify-between py-4 text-xs uppercase text-start"
                  >
                    <span>{t.deliveryAccordion}</span>
                    <ChevronDown
                      className={`w-4 h-4 transition-transform duration-200 ${
                        openAccordion === 'delivery' ? 'rotate-180' : ''
                      }`}
                    />
                  </button>
                  {openAccordion === 'delivery' && (
                    <div className="pb-4 text-xs text-muted-foreground leading-relaxed">
                      {t.deliveryText}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Column 2 (Center): Vertical Stack of Square Studio Images */}
          <div className="order-1 lg:order-2 space-y-2">
            {displayedImages.map((img, idx) => (
              <div
                key={idx}
                onClick={() => setLightboxIndex(idx)}
                className="aspect-square bg-secondary cursor-zoom-in overflow-hidden"
              >
                <img
                  src={img.url}
                  alt={img.alt || product.title[lang]}
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>

          {/* Column 3 (Sticky Right in LTR / Left in RTL): Color Swatches, Size Selector & Add to Bag */}
          <div className="order-3 lg:h-[calc(100vh-6rem)] lg:sticky lg:top-20">
            <div className="h-full flex flex-col justify-center space-y-6">
              {/* Color Swatches */}
              {product.colors.length > 0 && (
                <div>
                  <p className="text-xs text-muted-foreground mb-3 uppercase">
                    {t.colorLabel}:{' '}
                    <span className="text-foreground">
                      {selectedColorObj ? selectedColorObj[lang] : selectedColor}
                    </span>
                  </p>
                  <div className="flex gap-2">
                    {product.colors.map((c) => {
                      const active = selectedColor === c.id;
                      const isWhite = c.hex.toLowerCase() === '#ffffff';
                      return (
                        <button
                          key={c.id}
                          type="button"
                          onClick={() => setSelectedColor(c.id)}
                          title={c[lang]}
                          style={{ backgroundColor: c.hex }}
                          className={`w-10 h-10 border-2 transition-colors ${
                            active
                              ? 'border-foreground ring-2 ring-foreground ring-offset-2 ring-offset-background'
                              : isWhite
                              ? 'border-border hover:border-foreground'
                              : 'border-transparent hover:border-foreground'
                          }`}
                        >
                          <span className="sr-only">{c[lang]}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Size Selector */}
              <div className="hidden lg:block space-y-2">
                <p className="text-xs text-muted-foreground uppercase">
                  {t.selectSizeLabel}
                </p>
                <div className="grid grid-cols-4 gap-2">
                  {product.sizes.map((size) => {
                    const active = selectedSize === size;
                    return (
                      <button
                        key={size}
                        type="button"
                        onClick={() => setSelectedSize(size)}
                        className={`h-11 text-xs uppercase border transition-colors ${
                          active
                            ? 'border-foreground bg-foreground text-background'
                            : 'border-border hover:border-foreground'
                        }`}
                      >
                        {size}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Desktop Add to Bag Button */}
              <button
                type="button"
                onClick={() =>
                  onAddToCart(
                    product,
                    selectedSize,
                    selectedColorObj ? selectedColorObj[lang] : selectedColor
                  )
                }
                className="hidden lg:flex w-full h-12 bg-foreground text-background text-xs uppercase hover:opacity-90 transition-opacity items-center justify-center gap-2"
              >
                <span>
                  {t.addToBag} — {formatEGP(product.price, lang)}
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Fixed Bottom Action Bar (Exact VOID™ Mobile Pattern) */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-background border-t border-border page-padding py-3 space-y-3">
        <div className="grid grid-cols-4 gap-2">
          {product.sizes.map((size) => {
            const active = selectedSize === size;
            return (
              <button
                key={size}
                type="button"
                onClick={() => setSelectedSize(size)}
                className={`h-9 text-xs uppercase border transition-colors ${
                  active
                    ? 'border-foreground bg-foreground text-background'
                    : 'border-border hover:border-foreground'
                }`}
              >
                {size}
              </button>
            );
          })}
        </div>
        <button
          type="button"
          onClick={() =>
            onAddToCart(
              product,
              selectedSize,
              selectedColorObj ? selectedColorObj[lang] : selectedColor
            )
          }
          className="w-full h-12 bg-foreground text-background text-xs uppercase hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
        >
          <span>
            {t.addToBag} — {formatEGP(product.price, lang)}
          </span>
        </button>
      </div>

      {/* Lightbox Modal when clicking an image */}
      {lightboxIndex !== null && displayedImages[lightboxIndex] && (
        <div
          className="fixed inset-0 z-[120] bg-background flex items-center justify-center"
          onClick={() => setLightboxIndex(null)}
        >
          <button
            type="button"
            onClick={() => setLightboxIndex(null)}
            className="absolute top-4 end-4 z-10 p-2 hover:opacity-70 transition-opacity"
          >
            <X className="w-6 h-6" />
          </button>

          {displayedImages.length > 1 && (
            <>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setLightboxIndex(
                    (lightboxIndex - 1 + displayedImages.length) %
                      displayedImages.length
                  );
                }}
                className="absolute left-4 top-1/2 -translate-y-1/2 p-2 hover:opacity-70"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setLightboxIndex((lightboxIndex + 1) % displayedImages.length);
                }}
                className="absolute right-4 top-1/2 -translate-y-1/2 p-2 hover:opacity-70"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </>
          )}

          <img
            src={displayedImages[lightboxIndex].url}
            alt={displayedImages[lightboxIndex].alt}
            className="max-h-[90vh] max-w-[90vw] object-contain"
            onClick={(e) => e.stopPropagation()}
          />

          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-xs text-muted-foreground">
            {lightboxIndex + 1} / {displayedImages.length}
          </div>
        </div>
      )}
    </div>
  );
};
