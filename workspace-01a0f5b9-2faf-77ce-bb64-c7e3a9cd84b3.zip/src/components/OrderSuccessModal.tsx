import React, { useState } from 'react';
import { Check, Copy } from 'lucide-react';
import { Language, SubmittedOrder } from '../types/shop';
import { formatEGP, translations } from '../data/i18n';
import { TELEGRAM_BOT_USERNAME } from '../services/telegramService';

interface OrderSuccessModalProps {
  order: SubmittedOrder | null;
  onClose: () => void;
  lang: Language;
}

export const OrderSuccessModal: React.FC<OrderSuccessModalProps> = ({
  order,
  onClose,
  lang,
}) => {
  const [copied, setCopied] = useState(false);

  if (!order) return null;
  const t = translations[lang];

  const handleCopy = () => {
    navigator.clipboard.writeText(order.telegramCaption);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 overflow-y-auto">
      <div
        className="fixed inset-0 bg-foreground/40 animate-fade-in"
        onClick={onClose}
      />

      <div className="relative z-10 w-full max-w-lg bg-background border border-border p-6 sm:p-8 space-y-6 my-auto animate-fade-in">
        <div className="space-y-2 border-b border-border pb-4">
          <div className="flex items-center justify-between text-xs text-muted-foreground uppercase">
            <span>
              {t.orderReference}: #{order.orderId}
            </span>
            <span>{order.createdAt}</span>
          </div>
          <h2 className="text-base uppercase font-medium">
            {t.orderSuccessTitle}
          </h2>
          <p className="text-xs text-muted-foreground leading-relaxed">
            {t.orderSuccessSubtitle}
          </p>
        </div>

        {/* Telegram Status */}
        <div className="p-3 border border-border bg-secondary text-xs flex items-center justify-between gap-2">
          <span>
            {order.telegramDelivered
              ? t.telegramStatusLive
              : t.telegramStatusSimulated}
          </span>
          <a
            href={`https://t.me/${TELEGRAM_BOT_USERNAME}`}
            target="_blank"
            rel="noreferrer"
            className="underline underline-offset-4 uppercase flex-shrink-0"
          >
            @{TELEGRAM_BOT_USERNAME}
          </a>
        </div>

        {/* Receipt & Details */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center border border-border p-4">
          {order.receiptPreviewUrl && (
            <div className="sm:col-span-1">
              <img
                src={order.receiptPreviewUrl}
                alt="Receipt"
                className="w-full h-24 object-cover border border-border"
              />
            </div>
          )}
          <div className="sm:col-span-2 space-y-1 text-xs">
            <div className="flex justify-between">
              <span className="text-muted-foreground">{t.fullNameLabel}:</span>
              <span>{order.customer.fullName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">{t.phoneLabel}:</span>
              <span dir="ltr" className="font-mono">
                {order.customer.phone}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">
                {t.governorateLabel}:
              </span>
              <span>{order.customer.governorateName}</span>
            </div>
            <div className="flex justify-between pt-2 border-t border-border font-medium">
              <span>{t.subtotal}:</span>
              <span>{formatEGP(order.totalAmount, lang)}</span>
            </div>
          </div>
        </div>

        {/* Telegram Formatted Caption */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="uppercase text-muted-foreground">
              {t.telegramPayloadPreview}
            </span>
            <button
              type="button"
              onClick={handleCopy}
              className="inline-flex items-center gap-1 uppercase hover:opacity-60"
            >
              {copied ? (
                <>
                  <Check className="w-3 h-3" />
                  <span>{t.copiedButton}</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span>{t.copyButton}</span>
                </>
              )}
            </button>
          </div>
          <pre
            dir="ltr"
            className="p-3 bg-secondary border border-border text-xs font-mono whitespace-pre-wrap overflow-x-auto"
          >
            {order.telegramCaption}
          </pre>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full h-12 bg-foreground text-background text-xs uppercase hover:opacity-90 transition-opacity"
        >
          {t.continueShopping}
        </button>
      </div>
    </div>
  );
};
