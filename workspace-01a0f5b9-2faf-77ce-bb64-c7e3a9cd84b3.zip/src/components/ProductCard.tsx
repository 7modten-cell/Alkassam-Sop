import React, { useState } from 'react';
import { Plus, Check } from 'lucide-react';
import { Language, Product } from '../types/shop';
import { formatEGP, translations } from '../data/i18n';

interface ProductCardProps {
  product: Product;
  lang: Language;
  onSelectProduct: (product: Product) => void;
  onQuickAdd: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  lang,
  onSelectProduct,
  onQuickAdd,
}) => {
  const t = translations[lang];
  const [imageIndex, setImageIndex] = useState(0);
  const [justAdded, setJustAdded] = useState(false);

  const hasMultipleImages = product.images.length > 1;
  const activeImage = product.images[imageIndex] || product.images[0];

  const handleQuickAddClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onQuickAdd(product);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 900);
  };

  return (
    <div
      onClick={() => onSelectProduct(product)}
      onMouseEnter={() => hasMultipleImages && setImageIndex(1)}
      onMouseLeave={() => setImageIndex(0)}
      className="group block cursor-pointer"
    >
      {/* Square Studio Image Box */}
      <div className="aspect-square bg-secondary mb-3 overflow-hidden relative">
        {activeImage ? (
          <img
            src={activeImage.url}
            alt={activeImage.alt || product.title[lang]}
            loading="lazy"
            className="w-full h-full object-cover transition-opacity duration-200"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted-foreground text-xs">
            No image
          </div>
        )}

        {/* Brutalist Zero-Radius "New" Badge */}
        {product.isNew && (
          <div className="absolute top-2 start-2 bg-background border border-border text-foreground text-xs px-1.5 py-0.5 rounded-none font-normal uppercase">
            {t.newBadge}
          </div>
        )}

        {/* Sold Out Overlay */}
        {!product.inStock && (
          <div className="absolute bottom-0 left-0 right-0 bg-background/90 py-2 text-center">
            <span className="text-xs text-muted-foreground uppercase">
              {t.soldOutBadge}
            </span>
          </div>
        )}

        {/* Quick Add Button on Hover / Mobile */}
        {product.inStock && (
          <button
            type="button"
            onClick={handleQuickAddClick}
            title={t.addToBag}
            aria-label={t.addToBag}
            className="absolute bottom-2 end-2 h-8 px-2.5 bg-background/95 border border-border text-foreground hover:bg-foreground hover:text-background text-[11px] uppercase tracking-wide flex items-center gap-1 opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-all"
          >
            {justAdded ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>{t.addedToBag}</span>
              </>
            ) : (
              <>
                <Plus className="w-3.5 h-3.5" />
                <span>{t.addToBag}</span>
              </>
            )}
          </button>
        )}
      </div>

      {/* Product Title & Price in EGP */}
      <p className="text-xs mb-1 line-clamp-1 uppercase">
        {product.title[lang]}
      </p>
      <p className="text-xs text-muted-foreground">
        {formatEGP(product.price, lang)}
      </p>
    </div>
  );
};
