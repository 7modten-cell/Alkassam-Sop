import React, { useState } from 'react';
import { CategoryId, Language } from '../types/shop';
import { PAYMENT_CONFIG, translations } from '../data/i18n';
import {
  detectLatestTelegramChatId,
  TELEGRAM_BOT_USERNAME,
} from '../services/telegramService';

interface HamburgerMenuProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onToggleLang: () => void;
  selectedCategory: CategoryId;
  onSelectCategory: (cat: CategoryId) => void;
  onOpenSearch: () => void;
  savedChatId: string;
  onChangeChatId: (chatId: string) => void;
}

export const HamburgerMenu: React.FC<HamburgerMenuProps> = ({
  isOpen,
  onClose,
  lang,
  onToggleLang,
  selectedCategory,
  onSelectCategory,
  onOpenSearch,
  savedChatId,
  onChangeChatId,
}) => {
  const t = translations[lang];
  const [telegramOpen, setTelegramOpen] = useState(false);
  const [detecting, setDetecting] = useState(false);
  const [detectFeedback, setDetectFeedback] = useState<string | null>(null);

  if (!isOpen) return null;

  const categories: CategoryId[] = [
    'all',
    'new-arrivals',
    'essentials',
    'tops-tees',
    'hoodies-sweats',
  ];

  const handleAutoDetect = async () => {
    setDetecting(true);
    setDetectFeedback(null);
    const res = await detectLatestTelegramChatId();
    setDetecting(false);
    if (res.chatId) {
      onChangeChatId(res.chatId);
      setDetectFeedback(`${t.chatIdDetectedSuccess} ${res.chatId}`);
    } else {
      setDetectFeedback(t.chatIdNotFound);
    }
  };

  return (
    <div className="fixed inset-0 z-[100]">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-foreground/20 animate-fade-in"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Slide-in Brutalist Drawer */}
      <div
        className="absolute top-0 start-0 h-full w-[300px] max-w-[85vw] bg-background border-e border-border flex flex-col animate-fade-in"
        role="dialog"
        aria-modal="true"
        aria-label="Navigation menu"
      >
        {/* Top Header */}
        <div className="nav-height flex items-center justify-between page-padding border-b border-border">
          <span className="text-xs uppercase tracking-wide font-medium">
            VOID™ EGYPT
          </span>
          <button
            type="button"
            onClick={onClose}
            className="text-xs uppercase tracking-wide hover:opacity-60 transition-opacity"
          >
            {t.closeLabel}
          </button>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 py-8 page-padding overflow-y-auto">
          <ul className="space-y-4">
            {categories.map((cat) => (
              <li key={cat}>
                <button
                  type="button"
                  onClick={() => {
                    onSelectCategory(cat);
                    onClose();
                  }}
                  className={`text-sm uppercase hover:opacity-60 transition-opacity text-start w-full flex items-center justify-between ${
                    selectedCategory === cat
                      ? 'font-semibold underline underline-offset-4'
                      : ''
                  }`}
                >
                  <span>{t.categories[cat]}</span>
                </button>
              </li>
            ))}

            <li className="pt-2 border-t border-border">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenSearch();
                }}
                className="text-sm uppercase hover:opacity-60 transition-opacity"
              >
                {t.searchLabel}
              </button>
            </li>
          </ul>
        </nav>

        {/* Telegram Bot Configuration Accordion */}
        <div className="page-padding py-4 border-t border-border">
          <button
            type="button"
            onClick={() => setTelegramOpen((v) => !v)}
            className="text-xs uppercase tracking-wide hover:opacity-60 transition-opacity flex items-center justify-between w-full"
          >
            <span>TELEGRAM BOT (@{TELEGRAM_BOT_USERNAME})</span>
            <span className="text-muted-foreground">
              {telegramOpen ? '−' : '+'}
            </span>
          </button>

          {telegramOpen && (
            <div className="mt-3 space-y-2.5 text-xs">
              <p className="text-muted-foreground leading-relaxed text-[11px]">
                {t.telegramChatIdHelp}
              </p>
              <input
                type="text"
                dir="ltr"
                value={savedChatId}
                onChange={(e) => onChangeChatId(e.target.value)}
                placeholder={t.telegramChatIdPlaceholder}
                className="w-full h-9 px-2.5 border border-border bg-background text-xs font-mono outline-none focus:border-foreground"
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleAutoDetect}
                  disabled={detecting}
                  className="flex-1 h-8 bg-foreground text-background text-[11px] uppercase hover:opacity-80 transition-opacity"
                >
                  {detecting ? t.detectingChatId : t.autoDetectChatId}
                </button>
                <a
                  href={`https://t.me/${TELEGRAM_BOT_USERNAME}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-2.5 h-8 border border-border flex items-center justify-center text-[11px] uppercase hover:border-foreground"
                >
                  @Bot
                </a>
              </div>
              {detectFeedback && (
                <p className="text-[11px] text-muted-foreground border border-border p-2">
                  {detectFeedback}
                </p>
              )}
            </div>
          )}
        </div>

        {/* Region / Payment Info & Language Switch */}
        <div className="page-padding py-4 border-t border-border space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="uppercase text-muted-foreground">
              EGYPT (EGP / ج.م)
            </span>
            <button
              type="button"
              onClick={onToggleLang}
              className="uppercase underline underline-offset-4 hover:opacity-60"
            >
              {lang === 'ar' ? 'English (LTR)' : 'العربية (RTL)'}
            </button>
          </div>
          <div className="text-[11px] text-muted-foreground space-y-0.5 pt-1">
            <div>VF CASH: {PAYMENT_CONFIG.vodafoneCashNumber}</div>
            <div>INSTAPAY: {PAYMENT_CONFIG.instapayAddress}</div>
          </div>
        </div>

        {/* Copyright */}
        <div className="page-padding py-4 border-t border-border">
          <p className="text-xs text-muted-foreground">© 2026 VOID™ EGYPT</p>
        </div>
      </div>
    </div>
  );
};
