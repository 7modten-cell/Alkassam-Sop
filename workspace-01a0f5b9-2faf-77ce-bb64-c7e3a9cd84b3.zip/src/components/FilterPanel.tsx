import React from 'react';
import { X } from 'lucide-react';
import { CategoryId, Language } from '../types/shop';
import { translations } from '../data/i18n';

export type SortOption = 'default' | 'price-low' | 'price-high';

interface FilterPanelProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  sortBy: SortOption;
  onSortChange: (sort: SortOption) => void;
  selectedSizes: string[];
  onToggleSize: (size: string) => void;
  selectedCategory: CategoryId;
  onSelectCategory: (cat: CategoryId) => void;
  inStockOnly: boolean;
  onToggleInStock: (val: boolean) => void;
  onClearAll: () => void;
}

export const FilterPanel: React.FC<FilterPanelProps> = ({
  isOpen,
  onClose,
  lang,
  sortBy,
  onSortChange,
  selectedSizes,
  onToggleSize,
  selectedCategory,
  onSelectCategory,
  inStockOnly,
  onToggleInStock,
  onClearAll,
}) => {
  if (!isOpen) return null;

  const t = translations[lang];
  const availableSizes = ['S', 'M', 'L', 'XL'];
  const categories: CategoryId[] = [
    'all',
    'new-arrivals',
    'essentials',
    'tops-tees',
    'hoodies-sweats',
  ];

  const hasActiveFilters =
    sortBy !== 'default' ||
    selectedSizes.length > 0 ||
    selectedCategory !== 'all' ||
    inStockOnly;

  return (
    <div className="fixed inset-0 z-[100]">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-foreground/20 animate-fade-in"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Slide-out Filter Drawer */}
      <div
        className="absolute top-0 start-0 h-full w-[320px] max-w-[85vw] bg-background border-e border-border flex flex-col animate-fade-in"
        role="dialog"
        aria-modal="true"
        aria-label="Filter panel"
      >
        <div className="nav-height flex items-center justify-between page-padding border-b border-border">
          <span className="text-sm font-medium uppercase">
            {t.filtersButton}
          </span>
          <button
            type="button"
            onClick={onClose}
            className="p-2 -me-2 hover:opacity-60 transition-opacity"
            aria-label="Close filters"
          >
            <X className="w-5 h-5 stroke-[1.5]" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto py-6 page-padding">
          {/* Sort By */}
          <div className="mb-8">
            <h3 className="text-xs uppercase text-muted-foreground mb-4">
              {t.sortBy}
            </h3>
            <div className="space-y-3">
              {[
                { value: 'default' as SortOption, label: t.sortDefault },
                { value: 'price-low' as SortOption, label: t.sortPriceLow },
                { value: 'price-high' as SortOption, label: t.sortPriceHigh },
              ].map((opt) => (
                <label
                  key={opt.value}
                  className="flex items-center gap-3 text-sm cursor-pointer hover:opacity-60 transition-opacity"
                >
                  <input
                    type="radio"
                    name="sort"
                    checked={sortBy === opt.value}
                    onChange={() => onSortChange(opt.value)}
                    className="w-3 h-3 accent-foreground"
                  />
                  <span>{opt.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Size Filter */}
          <div className="mb-8">
            <h3 className="text-xs uppercase text-muted-foreground mb-4">
              {t.sizeLabel}
            </h3>
            <div className="flex flex-wrap gap-2">
              {availableSizes.map((size) => {
                const active = selectedSizes.includes(size);
                return (
                  <button
                    key={size}
                    type="button"
                    onClick={() => onToggleSize(size)}
                    className={`px-4 py-2 text-sm border transition-colors ${
                      active
                        ? 'border-foreground bg-foreground text-background'
                        : 'border-border hover:border-foreground'
                    }`}
                  >
                    {size}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Category Filter */}
          <div className="mb-8">
            <h3 className="text-xs uppercase text-muted-foreground mb-4">
              {t.categoryLabel}
            </h3>
            <div className="space-y-3">
              {categories.map((cat) => (
                <label
                  key={cat}
                  className="flex items-center gap-3 text-sm cursor-pointer hover:opacity-60 transition-opacity"
                >
                  <input
                    type="radio"
                    name="categoryFilter"
                    checked={selectedCategory === cat}
                    onChange={() => onSelectCategory(cat)}
                    className="w-3 h-3 accent-foreground"
                  />
                  <span>{t.categories[cat]}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Availability */}
          <div className="mb-8">
            <h3 className="text-xs uppercase text-muted-foreground mb-4">
              {t.availabilityLabel}
            </h3>
            <label className="flex items-center gap-3 text-sm cursor-pointer hover:opacity-60 transition-opacity">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={(e) => onToggleInStock(e.target.checked)}
                className="w-3 h-3 accent-foreground"
              />
              <span>{t.inStockOnly}</span>
            </label>
          </div>
        </div>

        {/* Footer Buttons */}
        <div className="page-padding py-4 border-t border-border flex gap-4">
          {hasActiveFilters && (
            <button
              type="button"
              onClick={onClearAll}
              className="flex-1 py-3 text-sm uppercase border border-border hover:border-foreground transition-colors"
            >
              {t.clearFilters}
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-3 text-sm uppercase bg-foreground text-background hover:opacity-80 transition-opacity"
          >
            {t.applyFilters}
          </button>
        </div>
      </div>
    </div>
  );
};
