import React from 'react';
import { Menu, Sun, Moon } from 'lucide-react';
import { Language } from '../types/shop';
import { translations } from '../data/i18n';

interface HeaderProps {
  lang: Language;
  onToggleLang: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenMenu: () => void;
  onOpenSearch: () => void;
  onLogoClick: () => void;
}

export const VoidLogo: React.FC<{ className?: string }> = ({ className = '' }) => (
  <svg
    width="48"
    height="12"
    viewBox="0 0 36 9"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <path
      d="M0.948 8.64L0 2.124H2.448L2.724 5.976L2.736 6.864L3.072 5.976L4.86 2.124H7.32L3.828 8.64H0.948Z"
      fill="currentColor"
    />
    <path
      d="M9.28444 8.868C7.52044 8.868 6.41644 7.812 6.41644 6.084C6.41644 3.888 7.97644 1.896 10.4004 1.896C12.1644 1.896 13.2684 2.952 13.2684 4.68C13.2684 6.876 11.7084 8.868 9.28444 8.868ZM9.52444 7.008C10.3284 7.008 10.8564 5.76 10.8564 4.68C10.8564 4.08 10.6284 3.756 10.1604 3.756C9.35644 3.756 8.82844 5.004 8.82844 6.084C8.82844 6.684 9.05644 7.008 9.52444 7.008Z"
      fill="currentColor"
    />
    <path
      d="M14.3929 1.62L14.7049 0H17.0329L16.7209 1.62H14.3929ZM13.0249 8.64L14.2969 2.124H16.6249L15.3529 8.64H13.0249Z"
      fill="currentColor"
    />
    <path
      d="M18.5018 8.868C17.1938 8.868 16.3538 7.8 16.3538 6.252C16.3538 3.924 17.8178 1.896 19.8218 1.896C20.4578 1.896 20.9378 2.136 21.2378 2.58L21.7418 0H24.0698L22.3898 8.64H20.0618L20.1578 8.16C19.6658 8.616 19.0898 8.868 18.5018 8.868ZM19.4498 7.008C20.2538 7.008 20.7698 5.592 20.7698 4.656C20.7698 4.068 20.5418 3.756 20.0858 3.756C19.3418 3.756 18.7778 4.98 18.7778 6.096C18.7778 6.696 19.0058 7.008 19.4498 7.008Z"
      fill="currentColor"
    />
    <path
      d="M24.7112 5.376L25.3832 1.908H24.0512L24.3272 0.48H28.7432L28.4672 1.908H27.1352L26.4632 5.376H24.7112ZM28.2272 5.376L29.1752 0.48H31.4312L31.5752 2.52L31.6472 3.6L32.1272 2.52L33.0752 0.48H35.2712L34.3232 5.376H32.5712L33.2432 2.496L32.5832 3.912L31.9232 5.376H30.6392L30.5312 3.876L30.4232 2.544L29.9912 5.376H28.2272Z"
      fill="currentColor"
    />
  </svg>
);

export const Header: React.FC<HeaderProps> = ({
  lang,
  onToggleLang,
  darkMode,
  onToggleDarkMode,
  cartCount,
  onOpenCart,
  onOpenMenu,
  onOpenSearch,
  onLogoClick,
}) => {
  const t = translations[lang];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 transition-all duration-300 bg-background/95 backdrop-blur-sm border-b border-border text-foreground">
      <nav className="nav-height flex items-center justify-between page-padding relative">
        {/* Start: Hamburger Menu + Language Toggle (AR/EN) directly next to it */}
        <div className="flex items-center gap-3 sm:gap-4">
          <button
            type="button"
            onClick={onOpenMenu}
            aria-label={t.menuButtonLabel}
            className="inline-flex items-center gap-1.5 text-xs uppercase tracking-wide hover:opacity-60 transition-opacity"
          >
            <Menu className="w-4 h-4 stroke-[1.5]" />
            <span>{t.menuButtonLabel}</span>
          </button>

          {/* Language Toggle (AR/EN) directly next to the menu button */}
          <button
            type="button"
            onClick={onToggleLang}
            className="px-2 py-1 border border-border text-xs uppercase tracking-wide hover:bg-secondary transition-colors font-mono"
            aria-label="Toggle Language"
          >
            {lang === 'ar' ? 'EN' : 'AR'}
          </button>
        </div>

        {/* Center: VOID™ Vector Logo */}
        <button
          type="button"
          onClick={onLogoClick}
          aria-label="VOID™ Home"
          className="absolute left-1/2 -translate-x-1/2 hover:opacity-70 transition-opacity"
        >
          <VoidLogo />
        </button>

        {/* End: Search + Theme Toggle + Cart */}
        <div className="flex items-center gap-3 sm:gap-5">
          <button
            type="button"
            onClick={onOpenSearch}
            className="hidden sm:inline-block text-xs uppercase tracking-wide hover:opacity-60 transition-opacity"
            aria-label={t.searchLabel}
          >
            {t.searchLabel}
          </button>

          {/* Light / Dark Mode Theme Switch */}
          <button
            type="button"
            onClick={onToggleDarkMode}
            title={darkMode ? t.themeLight : t.themeDark}
            aria-label={darkMode ? t.themeLight : t.themeDark}
            className="p-1.5 border border-border hover:bg-secondary transition-colors flex items-center justify-center"
          >
            {darkMode ? (
              <Sun className="w-3.5 h-3.5 stroke-[1.5]" />
            ) : (
              <Moon className="w-3.5 h-3.5 stroke-[1.5]" />
            )}
          </button>

          <button
            type="button"
            onClick={onOpenCart}
            className="text-xs uppercase tracking-wide hover:opacity-60 transition-opacity"
            aria-label={t.cartTitle}
          >
            {t.cartTitle}
            {cartCount > 0 ? ` (${cartCount})` : ''}
          </button>
        </div>
      </nav>
    </header>
  );
};
