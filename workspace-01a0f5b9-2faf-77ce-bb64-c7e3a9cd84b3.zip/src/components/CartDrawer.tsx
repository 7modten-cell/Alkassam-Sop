import React from 'react';
import { CartItem, Language } from '../types/shop';
import { formatEGP, translations } from '../data/i18n';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  items: CartItem[];
  onUpdateQuantity: (cartItemId: string, delta: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onProceedToCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  lang,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
}) => {
  if (!isOpen) return null;

  const t = translations[lang];
  const totalAmount = items.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );
  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="fixed inset-0 z-[100]">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-foreground/20 animate-fade-in"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Slide-in Cart Panel */}
      <div
        className="absolute top-0 end-0 h-full w-full max-w-[400px] bg-background border-s border-border flex flex-col animate-fade-in"
        role="dialog"
        aria-modal="true"
        aria-label="Shopping cart"
      >
        {/* Header */}
        <div className="nav-height flex items-center justify-between page-padding border-b border-border flex-shrink-0">
          <span className="text-sm uppercase tracking-wide">
            {t.cartTitle} ({totalItems})
          </span>
          <button
            type="button"
            onClick={onClose}
            className="text-xs uppercase tracking-wide hover:opacity-60 transition-opacity"
            aria-label="Close cart"
          >
            {t.closeLabel}
          </button>
        </div>

        {/* Body */}
        {items.length === 0 ? (
          <div className="flex-1 flex items-center justify-center p-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-4">
                {t.cartEmptyTitle}
              </p>
              <button
                type="button"
                onClick={onClose}
                className="text-sm underline underline-offset-4 hover:opacity-60 transition-opacity uppercase"
              >
                {t.continueShopping}
              </button>
            </div>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto">
              <div className="divide-y divide-border">
                {items.map((item) => (
                  <div key={item.cartItemId} className="p-4 flex gap-4">
                    <div className="w-20 h-20 bg-secondary flex-shrink-0">
                      <img
                        src={item.product.image}
                        alt={item.product.title[lang]}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    <div className="flex-1 min-w-0">
                      <p className="text-xs mb-1 line-clamp-1 uppercase">
                        {item.product.title[lang]}
                      </p>
                      {(item.selectedColor || item.selectedSize) && (
                        <p className="text-xs text-muted-foreground mb-2 uppercase">
                          {[item.selectedColor, item.selectedSize]
                            .filter(Boolean)
                            .join(' / ')}
                        </p>
                      )}
                      <p className="text-sm">
                        {formatEGP(item.product.price * item.quantity, lang)}
                      </p>

                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center border border-border">
                          <button
                            type="button"
                            onClick={() =>
                              onUpdateQuantity(item.cartItemId, -1)
                            }
                            className="w-8 h-8 flex items-center justify-center hover:bg-secondary transition-colors text-xs"
                            aria-label="Decrease quantity"
                          >
                            −
                          </button>
                          <span className="w-8 text-center text-xs">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() =>
                              onUpdateQuantity(item.cartItemId, 1)
                            }
                            className="w-8 h-8 flex items-center justify-center hover:bg-secondary transition-colors text-xs"
                            aria-label="Increase quantity"
                          >
                            +
                          </button>
                        </div>

                        <button
                          type="button"
                          onClick={() => onRemoveItem(item.cartItemId)}
                          className="text-xs text-muted-foreground underline underline-offset-4 hover:text-foreground transition-colors"
                        >
                          {t.remove}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Footer */}
            <div className="flex-shrink-0 border-t border-border p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm uppercase">{t.subtotal}</span>
                <span className="text-sm font-medium">
                  {formatEGP(totalAmount, lang)}
                </span>
              </div>
              <p className="text-xs text-muted-foreground">{t.shippingNote}</p>
              <button
                type="button"
                onClick={onProceedToCheckout}
                className="w-full h-12 bg-foreground text-background text-xs uppercase hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
              >
                {t.checkoutButton}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
