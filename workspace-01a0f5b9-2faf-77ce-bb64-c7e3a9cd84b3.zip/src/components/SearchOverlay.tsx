import React, { useState, useEffect, useRef } from 'react';
import { Language, Product } from '../types/shop';
import { formatEGP, translations } from '../data/i18n';
import { PRODUCTS } from '../data/products';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onSelectProduct: (product: Product) => void;
}

export const SearchOverlay: React.FC<SearchOverlayProps> = ({
  isOpen,
  onClose,
  lang,
  onSelectProduct,
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement | null>(null);
  const t = translations[lang];

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const q = query.trim().toLowerCase();
  const results =
    q.length > 0
      ? PRODUCTS.filter(
          (p) =>
            p.title.ar.toLowerCase().includes(q) ||
            p.title.en.toLowerCase().includes(q) ||
            p.description.ar.toLowerCase().includes(q) ||
            p.description.en.toLowerCase().includes(q)
        )
      : [];

  return (
    <div className="fixed inset-0 z-[100] bg-background animate-fade-in">
      <button
        type="button"
        onClick={onClose}
        className="absolute top-6 end-6 text-xs uppercase tracking-wide hover:opacity-60 transition-opacity"
        aria-label="Close search"
      >
        {t.closeLabel}
      </button>

      <div
        className="h-full flex flex-col items-center justify-center px-6"
        role="dialog"
        aria-modal="true"
        aria-label="Search"
      >
        <div className="w-full max-w-xl">
          <div className="flex items-center border-b border-border pb-4">
            <span className="text-sm text-muted-foreground me-4 flex-shrink-0 uppercase tracking-wide">
              {t.searchLabel}
            </span>
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="flex-1 bg-transparent outline-none text-lg"
            />
          </div>

          {q.length > 0 && (
            <div className="mt-8 max-h-[55vh] overflow-y-auto">
              {results.length > 0 ? (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {results.map((product) => (
                    <div
                      key={product.id}
                      onClick={() => {
                        onSelectProduct(product);
                        onClose();
                      }}
                      className="cursor-pointer hover:opacity-80 transition-opacity"
                    >
                      <div className="aspect-square bg-secondary mb-3">
                        <img
                          src={product.image}
                          alt={product.title[lang]}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <p className="text-xs mb-1 line-clamp-1 uppercase">
                        {product.title[lang]}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatEGP(product.price, lang)}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-sm text-muted-foreground">
                    {t.noProductsFound}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
