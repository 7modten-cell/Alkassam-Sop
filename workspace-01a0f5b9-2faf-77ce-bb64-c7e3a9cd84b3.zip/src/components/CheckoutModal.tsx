import React, { useState, useRef } from 'react';
import {
  Upload,
  Copy,
  Check,
  Loader2,
  AlertCircle,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  RefreshCw,
} from 'lucide-react';
import {
  CartItem,
  Language,
  PaymentMethod,
  SubmittedOrder,
} from '../types/shop';
import {
  EGYPT_GOVERNORATES,
  formatEGP,
  PAYMENT_CONFIG,
  translations,
} from '../data/i18n';
import {
  detectLatestTelegramChatId,
  sendOrderToTelegram,
  TELEGRAM_BOT_USERNAME,
} from '../services/telegramService';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  items: CartItem[];
  savedChatId: string;
  onChangeChatId: (id: string) => void;
  onOrderSuccess: (order: SubmittedOrder) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  lang,
  items,
  savedChatId,
  onChangeChatId,
  onOrderSuccess,
}) => {
  const t = translations[lang];
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [governorate, setGovernorate] = useState('');
  const [address, setAddress] = useState('');
  const [paymentMethod, setPaymentMethod] =
    useState<PaymentMethod>('Vodafone Cash');
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [receiptPreview, setReceiptPreview] = useState<string>('');

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [copiedTarget, setCopiedTarget] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [showTelegramConfig, setShowTelegramConfig] = useState(false);
  const [detectingChat, setDetectingChat] = useState(false);
  const [detectMsg, setDetectMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const totalAmount = items.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  // Strict 11-digit Egyptian mobile validation starting with "01"
  const isEgyptianPhoneValid = (val: string) => /^01\d{9}$/.test(val.trim());

  const handlePhoneChange = (value: string) => {
    const digitsOnly = value.replace(/\D/g, '').slice(0, 11);
    setPhone(digitsOnly);
    if (errors.phone && isEgyptianPhoneValid(digitsOnly)) {
      setErrors((prev) => ({ ...prev, phone: '' }));
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setErrors((prev) => ({ ...prev, receipt: t.paymentProofError }));
      return;
    }
    setReceiptFile(file);
    setReceiptPreview(URL.createObjectURL(file));
    setErrors((prev) => ({ ...prev, receipt: '' }));
  };

  const handleGenerateSampleReceipt = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 640;
    canvas.height = 400;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#09090b';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.strokeRect(16, 16, canvas.width - 32, canvas.height - 32);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 22px monospace';
    ctx.fillText('VOID™ EGYPT — PAYMENT RECEIPT', 36, 62);

    ctx.font = '16px monospace';
    ctx.fillText(`METHOD:  ${paymentMethod.toUpperCase()}`, 36, 115);
    ctx.fillText(`AMOUNT:  ${totalAmount} EGP`, 36, 150);
    ctx.fillText(
      `TARGET:  ${
        paymentMethod === 'Vodafone Cash'
          ? PAYMENT_CONFIG.vodafoneCashNumber
          : PAYMENT_CONFIG.instapayAddress
      }`,
      36,
      185
    );
    ctx.fillText(
      `SENDER:  ${fullName || 'CUSTOMER'} (${phone || '010XXXXXXXX'})`,
      36,
      220
    );
    ctx.fillText(`STATUS:  CONFIRMED TRANSFER`, 36, 255);
    ctx.fillStyle = '#a1a1aa';
    ctx.font = '13px monospace';
    ctx.fillText(`REF: VOID-${Date.now()}`, 36, 335);

    canvas.toBlob((blob) => {
      if (!blob) return;
      const sampleFile = new File([blob], 'void-payment-receipt.png', {
        type: 'image/png',
      });
      setReceiptFile(sampleFile);
      setReceiptPreview(URL.createObjectURL(sampleFile));
      setErrors((prev) => ({ ...prev, receipt: '' }));
    }, 'image/png');
  };

  const handleCopyPaymentTarget = () => {
    const target =
      paymentMethod === 'Vodafone Cash'
        ? PAYMENT_CONFIG.vodafoneCashNumber
        : PAYMENT_CONFIG.instapayAddress;
    navigator.clipboard.writeText(target);
    setCopiedTarget(true);
    setTimeout(() => setCopiedTarget(false), 1800);
  };

  const handleAutoDetectChatId = async () => {
    setDetectingChat(true);
    setDetectMsg(null);
    const res = await detectLatestTelegramChatId();
    setDetectingChat(false);
    if (res.chatId) {
      onChangeChatId(res.chatId);
      setDetectMsg(`${t.chatIdDetectedSuccess} ${res.chatId}`);
    } else {
      setDetectMsg(t.chatIdNotFound);
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (fullName.trim().length < 5) {
      newErrors.fullName = t.fullNameError;
    }

    if (!isEgyptianPhoneValid(phone)) {
      newErrors.phone = t.phoneError;
    }

    if (!governorate) {
      newErrors.governorate = t.governorateError;
    }

    if (address.trim().length < 5) {
      newErrors.address = t.addressError;
    }

    if (!receiptFile) {
      newErrors.receipt = t.paymentProofError;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm() || !receiptFile) return;

    setIsSubmitting(true);

    const govObj = EGYPT_GOVERNORATES.find((g) => g.id === governorate);
    const governorateName = govObj ? govObj[lang] : governorate;

    const telegramResult = await sendOrderToTelegram({
      fullName,
      phone,
      governorateName,
      address,
      paymentMethod,
      totalAmount,
      items,
      lang,
      receiptFile,
      chatId: savedChatId,
    });

    setIsSubmitting(false);

    const submittedOrder: SubmittedOrder = {
      orderId: `VOID-${Math.floor(100000 + Math.random() * 900000)}`,
      createdAt: new Date().toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-US'),
      customer: {
        fullName: fullName.trim(),
        phone: phone.trim(),
        governorateName,
        address: address.trim(),
        paymentMethod,
      },
      items: [...items],
      totalAmount,
      receiptPreviewUrl: receiptPreview,
      telegramCaption: telegramResult.caption,
      telegramDelivered: telegramResult.deliveredLive,
      telegramNote: telegramResult.errorMessage,
    };

    onOrderSuccess(submittedOrder);
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-foreground/40 animate-fade-in"
        onClick={() => !isSubmitting && onClose()}
      />

      {/* Brutalist Sharp-Corner Modal */}
      <div className="relative z-10 w-full max-w-2xl bg-background border border-border my-auto max-h-[92vh] flex flex-col animate-fade-in">
        {/* Top Bar */}
        <div className="nav-height flex items-center justify-between page-padding border-b border-border flex-shrink-0">
          <span className="text-xs sm:text-sm uppercase tracking-wide font-medium">
            {t.checkoutTitle}
          </span>
          <button
            type="button"
            disabled={isSubmitting}
            onClick={onClose}
            className="text-xs uppercase tracking-wide hover:opacity-60 transition-opacity"
          >
            {t.closeLabel}
          </button>
        </div>

        {/* Form Body */}
        <form
          onSubmit={handleSubmit}
          className="overflow-y-auto page-padding py-6 space-y-6"
        >
          {/* Order Total Bar */}
          <div className="p-4 bg-secondary border border-border flex items-center justify-between">
            <div className="text-xs uppercase">
              <span>{t.cartTitle}</span>{' '}
              <span className="text-muted-foreground">
                ({items.reduce((s, i) => s + i.quantity, 0)})
              </span>
            </div>
            <div className="text-sm font-semibold">
              {formatEGP(totalAmount, lang)}
            </div>
          </div>

          {/* 1. Customer Details */}
          <div className="space-y-4">
            <h3 className="text-xs uppercase text-muted-foreground tracking-wide border-b border-border pb-2">
              {t.customerInfoSection}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Full Name */}
              <div>
                <label className="block text-xs uppercase mb-1.5">
                  {t.fullNameLabel} *
                </label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => {
                    setFullName(e.target.value);
                    if (errors.fullName)
                      setErrors((p) => ({ ...p, fullName: '' }));
                  }}
                  placeholder={t.fullNamePlaceholder}
                  className={`w-full h-11 px-3 border bg-background text-xs outline-none transition-colors ${
                    errors.fullName
                      ? 'border-destructive'
                      : 'border-border focus:border-foreground'
                  }`}
                />
                {errors.fullName && (
                  <p className="mt-1 text-[11px] text-destructive flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    <span>{errors.fullName}</span>
                  </p>
                )}
              </div>

              {/* Egyptian Phone Number (11 digits starting with 01) */}
              <div>
                <label className="block text-xs uppercase mb-1.5">
                  {t.phoneLabel} *
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    dir="ltr"
                    value={phone}
                    onChange={(e) => handlePhoneChange(e.target.value)}
                    placeholder={t.phonePlaceholder}
                    maxLength={11}
                    className={`w-full h-11 px-3 border bg-background text-xs font-mono outline-none transition-colors ${
                      errors.phone
                        ? 'border-destructive'
                        : isEgyptianPhoneValid(phone)
                        ? 'border-foreground'
                        : 'border-border focus:border-foreground'
                    }`}
                  />
                  {isEgyptianPhoneValid(phone) && (
                    <CheckCircle2 className="w-4 h-4 text-foreground absolute end-3 top-3.5" />
                  )}
                </div>
                <p className="mt-1 text-[10px] text-muted-foreground">
                  {t.phoneHint} ({phone.length}/11)
                </p>
                {errors.phone && (
                  <p className="mt-1 text-[11px] text-destructive flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    <span>{errors.phone}</span>
                  </p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Governorate Dropdown */}
              <div className="sm:col-span-1">
                <label className="block text-xs uppercase mb-1.5">
                  {t.governorateLabel} *
                </label>
                <select
                  value={governorate}
                  onChange={(e) => {
                    setGovernorate(e.target.value);
                    if (errors.governorate)
                      setErrors((p) => ({ ...p, governorate: '' }));
                  }}
                  className={`w-full h-11 px-3 border bg-background text-xs outline-none transition-colors ${
                    errors.governorate
                      ? 'border-destructive'
                      : 'border-border focus:border-foreground'
                  }`}
                >
                  <option value="">{t.governoratePlaceholder}</option>
                  {EGYPT_GOVERNORATES.map((gov) => (
                    <option key={gov.id} value={gov.id}>
                      {gov[lang]}
                    </option>
                  ))}
                </select>
                {errors.governorate && (
                  <p className="mt-1 text-[11px] text-destructive flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    <span>{errors.governorate}</span>
                  </p>
                )}
              </div>

              {/* Full Address */}
              <div className="sm:col-span-2">
                <label className="block text-xs uppercase mb-1.5">
                  {t.addressLabel} *
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => {
                    setAddress(e.target.value);
                    if (errors.address)
                      setErrors((p) => ({ ...p, address: '' }));
                  }}
                  placeholder={t.addressPlaceholder}
                  className={`w-full h-11 px-3 border bg-background text-xs outline-none transition-colors ${
                    errors.address
                      ? 'border-destructive'
                      : 'border-border focus:border-foreground'
                  }`}
                />
                {errors.address && (
                  <p className="mt-1 text-[11px] text-destructive flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    <span>{errors.address}</span>
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* 2. Payment Methods (ONLY Vodafone Cash & InstaPay) */}
          <div className="space-y-4">
            <h3 className="text-xs uppercase text-muted-foreground tracking-wide border-b border-border pb-2">
              {t.paymentMethodSection} *
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Vodafone Cash */}
              <label
                className={`p-4 border cursor-pointer flex items-center gap-3 transition-colors ${
                  paymentMethod === 'Vodafone Cash'
                    ? 'border-foreground bg-secondary'
                    : 'border-border hover:border-foreground'
                }`}
              >
                <input
                  type="radio"
                  name="paymentMethod"
                  value="Vodafone Cash"
                  checked={paymentMethod === 'Vodafone Cash'}
                  onChange={() => setPaymentMethod('Vodafone Cash')}
                  className="w-3.5 h-3.5 accent-foreground"
                />
                <span className="text-xs uppercase font-medium">
                  {t.vodafoneCash}
                </span>
              </label>

              {/* InstaPay */}
              <label
                className={`p-4 border cursor-pointer flex items-center gap-3 transition-colors ${
                  paymentMethod === 'InstaPay'
                    ? 'border-foreground bg-secondary'
                    : 'border-border hover:border-foreground'
                }`}
              >
                <input
                  type="radio"
                  name="paymentMethod"
                  value="InstaPay"
                  checked={paymentMethod === 'InstaPay'}
                  onChange={() => setPaymentMethod('InstaPay')}
                  className="w-3.5 h-3.5 accent-foreground"
                />
                <span className="text-xs uppercase font-medium">
                  {t.instaPay}
                </span>
              </label>
            </div>

            {/* Dynamic Payment Instructions */}
            <div className="p-4 border border-border bg-secondary/60 space-y-3">
              <p className="text-xs text-muted-foreground">
                {paymentMethod === 'Vodafone Cash'
                  ? t.vodafoneInstructions
                  : t.instapayInstructions}
              </p>

              <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-background border border-border">
                <div>
                  <span className="text-[10px] uppercase text-muted-foreground block">
                    {paymentMethod === 'Vodafone Cash'
                      ? t.transferTargetNumber
                      : t.transferTargetInstapay}
                  </span>
                  <span
                    dir="ltr"
                    className="text-sm font-mono font-bold select-all"
                  >
                    {paymentMethod === 'Vodafone Cash'
                      ? PAYMENT_CONFIG.vodafoneCashNumber
                      : PAYMENT_CONFIG.instapayAddress}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-end">
                    <span className="text-[10px] uppercase text-muted-foreground block">
                      {t.amountToTransfer}
                    </span>
                    <span className="text-xs font-bold">
                      {formatEGP(totalAmount, lang)}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={handleCopyPaymentTarget}
                    className="h-9 px-3 bg-foreground text-background text-xs uppercase flex items-center gap-1.5 hover:opacity-80 transition-opacity"
                  >
                    {copiedTarget ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>{t.copiedButton}</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>{t.copyButton}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* 3. Payment Proof (Required Image Upload) */}
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border pb-2">
              <h3 className="text-xs uppercase text-muted-foreground tracking-wide">
                {t.paymentProofSection} *
              </h3>

              <button
                type="button"
                onClick={handleGenerateSampleReceipt}
                className="text-[11px] uppercase underline underline-offset-4 hover:opacity-60"
              >
                {t.generateSampleReceipt}
              </button>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />

            {!receiptFile ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                className={`border border-dashed p-6 text-center cursor-pointer transition-colors ${
                  errors.receipt
                    ? 'border-destructive bg-destructive/5'
                    : 'border-border hover:border-foreground bg-secondary/40'
                }`}
              >
                <Upload className="w-5 h-5 mx-auto mb-2 text-muted-foreground" />
                <p className="text-xs uppercase">{t.paymentProofDropzone}</p>
                <p className="text-[11px] text-muted-foreground mt-1">
                  {t.paymentProofHint}
                </p>
              </div>
            ) : (
              <div className="p-3 border border-foreground bg-secondary/40 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={receiptPreview}
                    alt="Receipt preview"
                    className="w-14 h-14 object-cover border border-border flex-shrink-0"
                  />
                  <div className="min-w-0">
                    <p className="text-xs truncate font-mono">
                      {receiptFile.name}
                    </p>
                    <p className="text-[11px] text-muted-foreground">
                      {(receiptFile.size / 1024).toFixed(1)} KB
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 flex-shrink-0">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="text-xs uppercase underline underline-offset-4 hover:opacity-60"
                  >
                    {t.changeImage}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setReceiptFile(null);
                      setReceiptPreview('');
                    }}
                    className="text-xs uppercase text-destructive underline underline-offset-4 hover:opacity-60"
                  >
                    {t.removeImage}
                  </button>
                </div>
              </div>
            )}

            {errors.receipt && (
              <p className="text-[11px] text-destructive flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                <span>{errors.receipt}</span>
              </p>
            )}
          </div>

          {/* Collapsible Telegram Bot Chat ID Config */}
          <div className="border border-border">
            <button
              type="button"
              onClick={() => setShowTelegramConfig((v) => !v)}
              className="w-full px-4 py-3 flex items-center justify-between text-xs uppercase bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <span>
                {t.telegramSettingsToggle}{' '}
                {savedChatId ? `(${savedChatId})` : `(@${TELEGRAM_BOT_USERNAME})`}
              </span>
              {showTelegramConfig ? (
                <ChevronUp className="w-4 h-4" />
              ) : (
                <ChevronDown className="w-4 h-4" />
              )}
            </button>

            {showTelegramConfig && (
              <div className="p-4 space-y-3 border-t border-border text-xs">
                <p className="text-muted-foreground leading-relaxed">
                  {t.telegramChatIdHelp}
                </p>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    dir="ltr"
                    value={savedChatId}
                    onChange={(e) => onChangeChatId(e.target.value)}
                    placeholder={t.telegramChatIdPlaceholder}
                    className="flex-1 h-10 px-3 border border-border bg-background font-mono text-xs outline-none focus:border-foreground"
                  />
                  <button
                    type="button"
                    onClick={handleAutoDetectChatId}
                    disabled={detectingChat}
                    className="h-10 px-4 bg-foreground text-background text-xs uppercase flex items-center justify-center gap-1.5"
                  >
                    <RefreshCw
                      className={`w-3.5 h-3.5 ${
                        detectingChat ? 'animate-spin' : ''
                      }`}
                    />
                    <span>
                      {detectingChat ? t.detectingChatId : t.autoDetectChatId}
                    </span>
                  </button>
                </div>
                {detectMsg && (
                  <p className="text-[11px] text-muted-foreground">{detectMsg}</p>
                )}
              </div>
            )}
          </div>

          {/* Submit Order Button with Spinner */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full h-12 bg-foreground text-background text-xs uppercase hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>{t.submittingOrder}</span>
              </>
            ) : (
              <span>
                {t.submitOrder} — {formatEGP(totalAmount, lang)}
              </span>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
